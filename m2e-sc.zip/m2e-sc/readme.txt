=== M2e Sales Channels ===
Tags: comments, spam
Requires at least: 6.1
Stable tag: 1.0.0
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A complete integration for Amazon, eBay & Walmart marketplaces