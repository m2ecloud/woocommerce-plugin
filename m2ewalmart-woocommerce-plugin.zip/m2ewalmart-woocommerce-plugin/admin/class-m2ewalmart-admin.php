<?php

/**
 * The file that defines the core plugin class
 *
 * A class definition that includes attributes and functions used across both the
 * public-facing side of the site and the admin area.
 *
 * @link       http://example.com
 * @since      1.0.0
 * @package    M2EWALMART
 * @subpackage M2EWALMART/admin
 */

defined( 'ABSPATH' ) || exit;

class M2EWALMART_Admin {

	/**
	 * The Facade object which interact with WordPress.
	 *
	 * @var M2EWALMART_Facade
	 */
	private $facade;

	public function __construct( M2EWALMART_Facade $facade ) {
		$this->facade = $facade;
	}

	public function disable_ssl_check( $curl ) {
		curl_setopt( $curl, CURLOPT_SSL_VERIFYHOST, 0 );
		curl_setopt( $curl, CURLOPT_SSL_VERIFYPEER, 0 );
	}

	public function check_auth() {
		if ( ! M2EWALMART_Helper::has_auth_data() ) {
			wp_redirect( site_url() . '/wc-auth/v1/authorize?' . M2EWALMART_Helper::build_authorize_params() );
		}
	}

	public function add_plugin_links( $links ) {
		$action_links = [
			'listings' => '<a href="' . admin_url( 'admin.php?page=m2ewalmart' ) . '" title="' . esc_html__( 'Manage Walmart Listings', 'm2ewalmart' ) . '">' . esc_html__( 'Manage Walmart Listings', 'm2ewalmart' ) . '</a>',
			'settings' => '<a href="' . admin_url( 'admin.php?page=m2ewalmart-settings' ) . '" title="' . esc_html__( 'Settings', 'm2ewalmart' ) . '">' . esc_html__( 'Settings', 'm2ewalmart' ) . '</a>',
		];

		return array_merge( $action_links, $links );
	}

	public function init_menu() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}

		$this->facade->add_menu_item(
			__( 'Walmart by M2E Cloud', 'm2ewalmart' ),
			__( 'Walmart by M2E ', 'm2ewalmart' ),
			'edit_posts',
			M2EWALMART_NAME,
			function () {
				$this->render_page( '/app/dashboard' );
			},
			'data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+CjxzdmcKICAgd2lkdGg9IjU4IgogICBoZWlnaHQ9IjU4IgogICB2aWV3Qm94PSIwIDAgNTggNTgiCiAgIGZpbGw9Im5vbmUiCiAgIHZlcnNpb249IjEuMSIKICAgaWQ9InN2ZzIiCiAgIHNvZGlwb2RpOmRvY25hbWU9IndhbG1hcnQuc3ZnIgogICBpbmtzY2FwZTp2ZXJzaW9uPSIxLjMgKDBlMTUwZWQsIDIwMjMtMDctMjEpIgogICB4bWxuczppbmtzY2FwZT0iaHR0cDovL3d3dy5pbmtzY2FwZS5vcmcvbmFtZXNwYWNlcy9pbmtzY2FwZSIKICAgeG1sbnM6c29kaXBvZGk9Imh0dHA6Ly9zb2RpcG9kaS5zb3VyY2Vmb3JnZS5uZXQvRFREL3NvZGlwb2RpLTAuZHRkIgogICB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciCiAgIHhtbG5zOnN2Zz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogIDxkZWZzCiAgICAgaWQ9ImRlZnMyIiAvPgogIDxzb2RpcG9kaTpuYW1lZHZpZXcKICAgICBpZD0ibmFtZWR2aWV3MiIKICAgICBwYWdlY29sb3I9IiNmZmZmZmYiCiAgICAgYm9yZGVyY29sb3I9IiMwMDAwMDAiCiAgICAgYm9yZGVyb3BhY2l0eT0iMC4yNSIKICAgICBpbmtzY2FwZTpzaG93cGFnZXNoYWRvdz0iMiIKICAgICBpbmtzY2FwZTpwYWdlb3BhY2l0eT0iMC4wIgogICAgIGlua3NjYXBlOnBhZ2VjaGVja2VyYm9hcmQ9IjAiCiAgICAgaW5rc2NhcGU6ZGVza2NvbG9yPSIjZDFkMWQxIgogICAgIGlua3NjYXBlOnpvb209IjguMTM3OTMxIgogICAgIGlua3NjYXBlOmN4PSIxNC4zMTU2NzgiCiAgICAgaW5rc2NhcGU6Y3k9IjMyLjY4NjQ0MSIKICAgICBpbmtzY2FwZTp3aW5kb3ctd2lkdGg9IjE1MTIiCiAgICAgaW5rc2NhcGU6d2luZG93LWhlaWdodD0iODYzIgogICAgIGlua3NjYXBlOndpbmRvdy14PSIwIgogICAgIGlua3NjYXBlOndpbmRvdy15PSIzOCIKICAgICBpbmtzY2FwZTp3aW5kb3ctbWF4aW1pemVkPSIxIgogICAgIGlua3NjYXBlOmN1cnJlbnQtbGF5ZXI9InN2ZzIiIC8+CiAgPHBhdGgKICAgICBkPSJtIDI5LjM2NjAyNCw3Ljg5ODgxMzUgYyAtMS42Nzc1MTksMCAtMy4wMTA3LDAuODk2NjYgLTMuMDEwNywxLjk4ODEwMSBsIDEuMDE4NzA0LDExLjA0MDYyMzUgYyAwLjExMjM2MywwLjY2NTIxOSAwLjk2Mzc0OSwxLjE3ODMzNSAxLjk5MjkxOSwxLjE3ODMzNSAxLjAzMTE3MSwtMC4wMDE0IDEuODc5NDczLC0wLjUxMzk1NiAxLjk5NDMwNCwtMS4xNzgzMzUgTCAzMi4zODQ3MjUsOS44ODY5MTQ1IGMgMCwtMS4wOTE0NDEgLTEuMzM2ODczLC0xLjk4Nzk2MiAtMy4wMTY3MDEsLTEuOTg3OTYyIHogTSAxMi43NjUyMzcsMTYuNzU1MTU1IGMgLTAuODcwNzc3LDAuMDE5NzMgLTEuODU5OTI1LDAuNjUwODA2IC0yLjQ4OTE4NywxLjY5NTA5MiAtMC44NDE2ODM1LDEuMzkwNDY3IC0wLjY5MjUyNjUsMi45NDQzNzEgMC4yOTIxNTcsMy40ODk1MzIgTCAyMS4wNjU4NiwyNi42MTkxMiBjIDAuNjU1NzM5LDAuMjMzNDAxIDEuNTQ2MzcyLC0wLjIxMjI3MSAyLjA2MjE4OCwtMS4wNjM0NTQgMS41NGUtNCwwIDAsLTIuODFlLTQgMCwtNC4yZS00IDAuNTE4MTI2LC0wLjg1NTI0MSAwLjQ3ODEwMywtMS44MTY5NjkgLTAuMDY3NDMsLTIuMjQzNDcxIGwgLTkuNDgxMjYsLTYuMzY1MTk3IGMgLTAuMjQ2MTI5LC0wLjEzNjQzIC0wLjUyMzIsLTAuMTk3ODU5IC0wLjgxMzUxMSwtMC4xOTEyODIgeiBtIDMzLjIwMTQxOSwwIGMgLTAuMjkwMzEsLTAuMDA2NSAtMC41NjY3NjcsMC4wNTQ4NSAtMC44MTI1OTIsMC4xOTEyODIgbCAtOS40ODI0OTEsNi4zNjUxOTkgYyAtMC41NDIxMzksMC40MjY1IC0wLjU4MjQ2NywxLjM4ODIyOCAtMC4wNjY5NywyLjI0MzQ2OSBsIDYuMTZlLTQsNC4yMWUtNCBjIDAuNTE3NjY0LDAuODUxMTgzIDEuNDA1Mzc0LDEuMjk2ODU1IDIuMDYxMjY0LDEuMDYzNDU1IGwgMTAuNTAyMjcyLC00LjY3OTA2MyBjIDAuOTg4Njg3LC0wLjU0NTE2IDEuMTMwNDU1LC0yLjA5OTA2MyAwLjI5NDYyLC0zLjQ4OTUzMiAtMC42MzIxODYsLTEuMDQ0Mjg0IC0xLjYyMzAyOCwtMS42NzUzNjEgLTIuNDkzODA0LC0xLjY5NTA5IHogTSAyMS40NTgwNzIsMzEuMzIxNjkxIGMgLTAuMTM1OTE5LC0wLjAwMTYgLTAuMjY3NTI5LDAuMDE4MzIgLTAuMzkwODI2LDAuMDYyNjkgbCAtMTAuNDk3NjUzLDQuNjczNzQxIGMgLTAuOTg0NTI5NSwwLjU0NzU0IC0xLjEzMzY4NjUsMi4xMDIwMDMgLTAuMjkyMTU3LDMuNDk0MDEgMC44MzkwNjcsMS4zODc4MDggMi4zMTc4NjMsMi4wNDc1NyAzLjMwMjcwMSwxLjUwMzI0OSBsIDkuNDgyMDMsLTYuMzYwMTYxIGMgMC41NDU1MjQsLTAuNDMxNjc5IDAuNTg1NywtMS4zOTMxMjUgMC4wNjc0MywtMi4yNDc1MjcgbCAwLjAwNDMsMC4wMDE4IGMgLTAuNDE5MTUsLTAuNjk2MDAzIC0xLjA4NzM1NSwtMS4xMjAyNjYgLTEuNjc1ODI2LC0xLjEyNzk2MSB6IG0gMTUuODIwNTIsMCBjIC0wLjU4Nzg1NSwwLjAwNzcgLTEuMjU0ODI5LDAuNDMxOTU5IC0xLjY3NDkwMSwxLjEyNzk2MSBsIDAuMDAzOCwtMC4wMDE4IGMgLTAuNTE1ODE3LDAuODU0NDAyIC0wLjQ3NTk0OSwxLjgxNTg0OSAwLjA2NjQ5LDIuMjQ3NTI4IGwgOS40ODIzMzcsNi4zNjAzMDEgYyAwLjk4MzE0NSwwLjU0NDE4MSAyLjQ2MzMyOCwtMC4xMTU1NzcgMy4zMDYyNDIsLTEuNTAzMzkgMC44MzU4MzUsLTEuMzkyMDA2IDAuNjk0MDY3LC0yLjk0NjQ3IC0wLjI5NDYyLC0zLjQ5NDAwOSBMIDM3LjY2ODg4OCwzMS4zODQ3MTkgYyAtMC4xMjMyOSwtMC4wNDQ1IC0wLjI1NDU5OSwtMC4wNjQ1MSAtMC4zOTAzNjUsLTAuMDYyODIgeiBtIC03LjkxNDEwOCw0LjU3NTc5NSBjIC0xLjAyNzQ3NiwwLjAwMTEgLTEuODc2NzAzLDAuNTExOTk4IC0xLjk4OTA3MiwxLjE3NTM5OCBMIDI2LjM1NjcxLDQ4LjExMzA4NiBjIDAsMS4wOTM0IDEuMzMzMTc5LDEuOTg4MTAxIDMuMDEwNjk4LDEuOTg4MTAxIDEuNjgwNDQ0LDAgMy4wMTYyNDEsLTAuODk0NzAxIDMuMDE2MjQxLC0xLjk4ODEwMSBMIDMxLjM2MjQ4MywzNy4wNzI4ODQgYyAtMC4xMTQ4MzEsLTAuNjYzNCAtMC45NjI5NzksLTEuMTc0MTM5IC0xLjk5NDMwNSwtMS4xNzUzOTggaCAtMC4wMDM2IHoiCiAgICAgZmlsbD0iIzIyMmI0NSIKICAgICBpZD0icGF0aDEiCiAgICAgc3R5bGU9InN0cm9rZS13aWR0aDoxLjQ2NzYyO2ZpbGw6I2Y5ZjlmOSIgLz4KPC9zdmc+Cg==',
			'56.505',
			[ $this, 'check_auth' ]
		);
	}

	private function render_page( $path ) {
		$params = [
			'woocommerce_embedded' => '1',
			'session_token' => M2EWALMART_Helper::build_jwt_token(),
		];
		$url = M2EWALMART_Helper::get_server_endpoint() . $path . '?' . http_build_query( $params );
		?>
		<iframe class="m2ewalmart-frame" src="<?php echo esc_url( $url ); ?>" frameborder="0"></iframe>
		<?php
	}
}
