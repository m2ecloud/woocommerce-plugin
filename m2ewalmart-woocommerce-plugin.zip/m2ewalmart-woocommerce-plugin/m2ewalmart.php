<?php
/**
 * Plugin Name:       Walmart by M2E Cloud
 * Plugin URI:        https://walmart.m2ecloud.com/
 * Description:       One-click integration between WooCommerce and Walmart. Easy inventory and order management.
 * Version:           1.0.0
 * Requires at least: 6.1
 * Requires PHP:      7.2
 * Author:            M2E Cloud
 * Author URI:        https://m2ecloud.com/about
 * License:           GPLv2
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.html
 *
 * Woo:                  replacewithreal:hash
 * WC requires at least: 8.0.0
 * WC tested up to:      8.0.2
 */

defined( 'ABSPATH' ) || exit;

define( 'M2EWALMART_NAME', 'm2ewalmart' );
define( 'M2EWALMART_VERSION', '1.0.0' );

if ( ! defined( 'M2EWALMART_PLUGIN_FILE' ) ) {
	define( 'M2EWALMART_PLUGIN_FILE', __FILE__ );
}

require plugin_dir_path( __FILE__ ) . 'includes/class-m2ewalmart-bootstrap.php';
M2EWALMART_Bootstrap::load_classes();
M2EWALMART_Bootstrap::register_activate();
M2EWALMART_Bootstrap::register_deactivate();

( new M2EWALMART_Bootstrap() )->run();
