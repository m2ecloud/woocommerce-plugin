<?php

/**
 * The file that defines the core plugin class
 *
 * A class definition that includes attributes and functions used across both the
 * public-facing side of the site and the admin area.
 *
 * @link       http://example.com
 * @since      1.0.0
 * @package    M2EEBAY
 * @subpackage M2EEBAY/admin
 */

defined( 'ABSPATH' ) || exit;

class M2EEBAY_Admin {

	/**
	 * The Facade object which interact with WordPress.
	 *
	 * @var M2EEBAY_Facade
	 */
	private $facade;

	public function __construct( M2EEBAY_Facade $facade ) {
		$this->facade = $facade;
	}

	public function disable_ssl_check( $curl ) {
		curl_setopt( $curl, CURLOPT_SSL_VERIFYHOST, 0 );
		curl_setopt( $curl, CURLOPT_SSL_VERIFYPEER, 0 );
	}

	public function check_auth() {
		if ( ! M2EEBAY_Helper::has_auth_data() ) {
			wp_redirect( site_url() . '/wc-auth/v1/authorize?' . M2EEBAY_Helper::build_authorize_params() );
		}
	}

	public function add_plugin_links( $links ) {
		$action_links = [
			'listings' => '<a href="' . admin_url( 'admin.php?page=m2eebay' ) . '" title="' . esc_html__( 'Manage eBay Listings', 'm2eebay' ) . '">' . esc_html__( 'Manage eBay Listings', 'm2eebay' ) . '</a>',
			'settings' => '<a href="' . admin_url( 'admin.php?page=m2eebay-settings' ) . '" title="' . esc_html__( 'Settings', 'm2eebay' ) . '">' . esc_html__( 'Settings', 'm2eebay' ) . '</a>',
		];

		return array_merge( $action_links, $links );
	}

	public function init_menu() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}

		$this->facade->add_menu_item(
			__( 'eBay by M2E Cloud', 'm2eebay' ),
			__( 'eBay by M2E', 'm2eebay' ),
			'edit_posts',
			M2EEBAY_NAME,
			function () {
				$this->render_page( '/app/dashboard' );
			},
			'data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+CjxzdmcKICAgd2lkdGg9IjU4IgogICBoZWlnaHQ9IjU4IgogICB2aWV3Qm94PSIwIDAgNTggNTgiCiAgIGZpbGw9Im5vbmUiCiAgIHZlcnNpb249IjEuMSIKICAgaWQ9InN2ZzQiCiAgIHNvZGlwb2RpOmRvY25hbWU9ImViYXkuc3ZnIgogICBpbmtzY2FwZTp2ZXJzaW9uPSIxLjMgKDBlMTUwZWQsIDIwMjMtMDctMjEpIgogICB4bWxuczppbmtzY2FwZT0iaHR0cDovL3d3dy5pbmtzY2FwZS5vcmcvbmFtZXNwYWNlcy9pbmtzY2FwZSIKICAgeG1sbnM6c29kaXBvZGk9Imh0dHA6Ly9zb2RpcG9kaS5zb3VyY2Vmb3JnZS5uZXQvRFREL3NvZGlwb2RpLTAuZHRkIgogICB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciCiAgIHhtbG5zOnN2Zz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgogIDxkZWZzCiAgICAgaWQ9ImRlZnM0IiAvPgogIDxzb2RpcG9kaTpuYW1lZHZpZXcKICAgICBpZD0ibmFtZWR2aWV3NCIKICAgICBwYWdlY29sb3I9IiNmZmZmZmYiCiAgICAgYm9yZGVyY29sb3I9IiMwMDAwMDAiCiAgICAgYm9yZGVyb3BhY2l0eT0iMC4yNSIKICAgICBpbmtzY2FwZTpzaG93cGFnZXNoYWRvdz0iMiIKICAgICBpbmtzY2FwZTpwYWdlb3BhY2l0eT0iMC4wIgogICAgIGlua3NjYXBlOnBhZ2VjaGVja2VyYm9hcmQ9IjAiCiAgICAgaW5rc2NhcGU6ZGVza2NvbG9yPSIjZDFkMWQxIgogICAgIHNob3dncmlkPSJmYWxzZSIKICAgICBpbmtzY2FwZTp6b29tPSIxMS4yMDY4OTciCiAgICAgaW5rc2NhcGU6Y3g9IjMyLjUyNDYxNCIKICAgICBpbmtzY2FwZTpjeT0iMjguOTk5OTk5IgogICAgIGlua3NjYXBlOndpbmRvdy13aWR0aD0iMTUxMiIKICAgICBpbmtzY2FwZTp3aW5kb3ctaGVpZ2h0PSI4NjMiCiAgICAgaW5rc2NhcGU6d2luZG93LXg9IjAiCiAgICAgaW5rc2NhcGU6d2luZG93LXk9IjM4IgogICAgIGlua3NjYXBlOndpbmRvdy1tYXhpbWl6ZWQ9IjEiCiAgICAgaW5rc2NhcGU6Y3VycmVudC1sYXllcj0ic3ZnNCIgLz4KICA8cGF0aAogICAgIGQ9Im0gOS4xNjk0NTg0LDE4LjcyMDQ0MSBjIC0zLjczNjE1OTQsMCAtNi44NDk0NTg1LDIuNDk2OTE2IC02Ljg0OTQ1ODUsMTAuMDMwNDQ5IDAsNS45NjgxNTggMi4wOTM0ODQ5LDkuNzI2NDE2IDYuOTQ2MDEzOCw5LjcyNjQxNiA1LjcxMTU1MTMsMCA1Ljk4ODQwNzMsLTYuNTUxNzQxIDUuOTg4NDA3MywtNi41NTE3NDEgbCAtMy4yMTM2MjgsMC4wODkyMyBjIDAsMCAtMC4xNDcxODksMi41NjcwMyAtMy4wMzI4NTczLDIuNTY3MDMgLTIuMzUwMjMzMywwIC0zLjE0ODQwMjYsLTAuNDQ4OTc2IC0zLjE0ODQwMjYsLTMuOTU0Njk5IGwgOS41MDU4NDI5LC0wLjA4OTIzIDAuMTc4NDYxLC0zLjA5MjE3NCBjIDAuMTk5ODMsLTMuNDYyNDIgLTEuMzA4MzI2LC04LjcyNTI4IC02LjM3NDM3ODYsLTguNzI1MjggeiBtIC0wLjI3NDg5MzUsMy43OTI5NyBjIDIuMjM3MTY4MSwwIDMuMDQ4NTc4MSwxLjE3NzczMSAzLjA0ODU3ODEsNC40MTM2OCBMIDUuOTIwNjkyNiwyNi44Mzc4NiBjIDAsLTMuNDM1NDQxIDEuMDA5MjM3MSwtNC4zMjQ0NDkgMi45NzM4NzIzLC00LjMyNDQ0OSB6IgogICAgIGZpbGw9IiMyMjJiNDUiCiAgICAgaWQ9InBhdGgxIgogICAgIHN0eWxlPSJmaWxsOiNmOWY5Zjk7c3Ryb2tlLXdpZHRoOjEuNjUyMjQiCiAgICAgc29kaXBvZGk6bm9kZXR5cGVzPSJzc3NjY3NjY3Nzc2Njc2MiIC8+CiAgPHBhdGgKICAgICBkPSJtIDE1LjYzMDY5MiwxMS40MjE1MzYgdiAyMy4yNjg3MDEgYyAwLDEuMzIwNzA5IC0wLjA1OTc4LDMuMTc1MjggLTAuMDU5NzgsMy4xNzUyOCBsIDMuNzEwNDIxLDAuMDg5MjMgYyAwLDAgLTAuMDgzNzgsLTEuNjg4NzYxIC0wLjA4Mzc4LC0yLjkwNjIyNCAwLDAgMC40MTE4MiwzLjQ4MTgxOCAzLjk1Nzk5NCwzLjQ4MTgxOCAzLjczNDE1OCwwIDYuMjcwNjI0LC00LjA4NDExNiA2LjI3MDYyNCwtOS45MzUyODkgMCwtNS40NDM0NTUgLTIuMzI5ODQ1LC05LjgyMTU3NiAtNi4yNjQ2MiwtOS44MjE1NzYgLTMuNjg0NjMxLDAgLTMuNzU4ODk3LDIuODY2NzcyIC0zLjc1ODg5NywyLjg2Njc3MiBsIDAuMDg5MjMsLTEwLjEyOTQ4MiB6IG0gNi45Mzg2OSwxMS43NDY4NzEgYyAyLjUzNTg0MSwwIDMuMDc3NjI3LDEuNjI2NDA4IDMuMDc3NjI3LDUuNjA1MTA4IDAsNC4yNjYxNDkgLTAuNzAyNDQ5LDUuNTQwMzYyIC0yLjk3MDI2LDUuNTQwMzYyIC0yLjcwNjQ0LDAgLTIuNzM4NzE4LC0yLjA3OTcwNCAtMi43Mzg3MTgsLTUuNzcwMDc3IDAsLTMuNDM4OTM3IC0wLjIwNjc4OSwtNS4zNzUzOTMgMi42MzEzNTEsLTUuMzc1MzkzIHoiCiAgICAgZmlsbD0iIzIyMmI0NSIKICAgICBpZD0icGF0aDIiCiAgICAgc3R5bGU9ImZpbGw6I2Y5ZjlmOTtzdHJva2Utd2lkdGg6MS42NTIyNCIKICAgICBzb2RpcG9kaTpub2RldHlwZXM9ImNzY2Njc3NzY2Njc3Nzc3MiIC8+CiAgPHBhdGgKICAgICBkPSJtIDM1Ljk4NjU4NCwxOC43MjA0NDEgYyAtNS42MjA3NSwwIC01Ljk4MTIwOSw0Ljg0ODI1MyAtNS45ODEyMDksNS42MjMwODYgbCAzLjY5MDA1MiwtMC4wODkyMyBjIDAsMCAtMC44MzQ4MzEsLTEuNTgxNDA5IDIuMDA5MDYxLC0xLjU4MTQwOSAxLjg0Nzk0NCwwIDIuNTg3Njg4LDAuOTIyMjI5IDIuNjU1NDA3LDIuMDIwNjAzIGwgMC4wODkyMywxLjQ0NzI4NiAtMi42NTU0MDcsMC4xNzg0NjIgYyAtNC4zNDQ3MTUsMC4yOTE5OTUgLTYuNjU2NTk0LDIuMDA2Njk5IC02LjY1NjU5NCw2LjA3OTAzMiAwLDQuMDA3NzI2IDIuMTI3MTA0LDYuMTg4MzggNS4wMDE1MTQsNi4xODgzOCAzLjkxNzM4OSwwIDQuMzc2MTY1LC0yLjc4NTUxIDQuMzc2MTY1LC0yLjc4NTUxIDAsMS4zNTY1MDMgLTAuMDIyODEsMi4xNTc1MzkgLTAuMDIyODEsMi4xNTc1MzkgbCAzLjM3OTM2OSwtMC4wODkyMyBjIDAsMCAtMC4wOTY0MywtMS42NTY2MTUgLTAuMDk2NDMsLTIuNzE2NDk1IHYgLTkuMTYxNTUgYyAwLC02LjAwNjc4NSAtMy4wNzU2NTEsLTcuMjcwOTYyIC01Ljc4ODM0MywtNy4yNzA5NjIgeiBtIDEuNzQ4Njk2LDEwLjI0NTAzOSAwLjA4OTIzLDEuNDgzNjMgYyAwLjA5NTIsMS41ODI4MTYgMC42MjgxMjEsNC4yNzg5MTQgLTMuMDI4NzQxLDQuMjc4OTE0IC0yLjAwMjQwNywwIC0xLjc5MDEzNSwtMC41MDM1NTUgLTEuNzkwMTM1LC0yLjMyOTc1NCAwLC0zLjMyMjE3MSAwLjQ4MTk0MSwtMy40MzI3OSA0LjcyOTY0NiwtMy40MzI3OSB6IgogICAgIGZpbGw9IiMyMjJiNDUiCiAgICAgaWQ9InBhdGgzIgogICAgIHN0eWxlPSJmaWxsOiNmOWY5Zjk7c3Ryb2tlLXdpZHRoOjEuNjUyMjQiCiAgICAgc29kaXBvZGk6bm9kZXR5cGVzPSJzY2Nzc2Nzc3NjY2Nzc3NzY3Nzc2MiIC8+CiAgPHBhdGgKICAgICBkPSJtIDQwLjI2NzgwNiwxOS40NzE5MTggNC4xMjg4NTcsLTAuMDg5MjMgMy42MjQ2NzksMTEuMDQzNjk2IDMuMTY4MTQxLC0xMS4yMjIxNTcgNC4xMDAzOCwwLjI2NzY5MiAtOC4yMDg3NDMsMjUuMzgwMTY2IC00LjMyOTA2NSwwLjA4OTIzIDIuNzI1NjY2LC05Ljc1MTg4NyB6IgogICAgIGZpbGw9IiMyMjJiNDUiCiAgICAgaWQ9InBhdGg0IgogICAgIHN0eWxlPSJmaWxsOiNmOWY5Zjk7c3Ryb2tlLXdpZHRoOjEuNjUyMjQiCiAgICAgc29kaXBvZGk6bm9kZXR5cGVzPSJjY2NjY2NjY2MiIC8+Cjwvc3ZnPgo=',
			'56.503',
			[ $this, 'check_auth' ]
		);
	}

	private function render_page( $path ) {
		$params = [
			'woocommerce_embedded' => '1',
			'session_token' => M2EEBAY_Helper::build_jwt_token(),
		];
		$url = M2EEBAY_Helper::get_server_endpoint() . $path . '?' . http_build_query( $params );
		?>
		<iframe class="m2eebay-frame" src="<?php echo esc_url( $url ); ?>" frameborder="0"></iframe>
		<?php
	}
}
