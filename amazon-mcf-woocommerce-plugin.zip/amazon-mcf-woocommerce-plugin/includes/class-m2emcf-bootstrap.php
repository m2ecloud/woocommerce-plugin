<?php

/**
 * The file that defines the core plugin class
 *
 * A class definition that includes attributes and functions used across both the
 * public-facing side of the site and the admin area.
 *
 * @link       http://example.com
 * @since      1.0.0
 * @package    M2EMCF
 * @subpackage M2EMCF/includes
 */

defined( 'ABSPATH' ) || exit;

class M2EMCF_Bootstrap {
	public static function register_activate() {
		register_activation_hook( M2EMCF_PLUGIN_FILE, function () {
			require_once plugin_dir_path( M2EMCF_PLUGIN_FILE ) . 'admin/class-m2emcf-activator.php';
			M2EMCF_Activator::activate();
		} );
	}

	public static function register_deactivate() {
		register_deactivation_hook( M2EMCF_PLUGIN_FILE, function () {
			require_once plugin_dir_path( M2EMCF_PLUGIN_FILE ) . 'admin/class-m2emcf-deactivator.php';
			M2EMCF_Deactivator::deactivate();
		} );
	}

	public static function load_classes() {
		require_once plugin_dir_path( __DIR__ ) . 'includes/class-m2emcf-helper.php';
		require_once plugin_dir_path( __DIR__ ) . 'includes/class-m2emcf-facade.php';
		require_once plugin_dir_path( __DIR__ ) . 'admin/class-m2emcf-admin.php';
	}

	public function run() {
		$facade       = new M2EMCF_Facade();
		$plugin_admin = new M2EMCF_Admin( $facade );

		$facade->add_action( 'admin_init', function () {
			if ( get_option( 'm2emcf_do_activation_redirect', false ) ) {
				require_once plugin_dir_path( M2EMCF_PLUGIN_FILE ) . 'admin/class-m2emcf-activator.php';
				delete_option( 'm2emcf_do_activation_redirect' );
				M2EMCF_Activator::install();
			}
		} );

		$facade->add_action( 'admin_enqueue_scripts', function () use ( $facade ) {
			$facade->enqueue_styles( 'admin/css/m2emcf-admin.css' );
		} );
		$facade->add_action( 'admin_enqueue_scripts', function () use ( $facade ) {
			$facade->enqueue_scripts( 'admin/js/m2emcf-admin.js', [ 'jquery' ] );
		} );
		$facade->add_action( 'admin_menu', [ $plugin_admin, 'init_menu' ] );
		$facade->add_filter( 'plugin_action_links_' . plugin_basename( M2EMCF_PLUGIN_FILE ), [$plugin_admin, 'add_plugin_links'] );

		$facade->add_action( 'before_woocommerce_init', function() {
			if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
				\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', M2EMCF_PLUGIN_FILE, true );
			}
		} );

		if ( getenv( 'WORDPRESS_DEBUG' ) ) {
			$facade->add_action( 'http_api_curl', [ $plugin_admin, 'disable_ssl_check' ] );
			$facade->add_filter('http_request_host_is_external', function() {
				return true;
			} );
		}

		$facade->run();
	}
}
