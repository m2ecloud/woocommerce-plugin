=== M2E Multi-Channel Fulfillment by Amazon ===
Tags: amazon, amazon mcf, fulfillment by amazon, fba, multichannel fulfillment, afn
Requires at least: 6.1
Tested up to: 6.4
Requires PHP: 7.2
Stable tag: 2.2.7
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

M2E Multi-Channel Fulfillment by Amazon allows businesses to use Amazon FBA's advanced fulfillment network to manage and ship WooCommerce orders.

== Description ==
With M2E Multi-Channel Fulfillment by Amazon, you can connect your WordPress store with Amazon MCF. The app automatically links your WooCommerce and Amazon FBA inventory, as well as imports WooCommerce orders for fulfillment by Amazon.

Let Amazon manage the logistics of order fulfillment, so you can focus on expanding your product offerings, refining marketing strategies, and growing your customer base.

- Automate order fulfillment: Ensure fast, reliable delivery with Amazon’s logistics network.
- Maintain real-time inventory sync: Keep stock levels accurate between WooCommerce and Amazon.
- Reduce overheads: Eliminate the need for separate warehouses and fulfillment staff by using Amazon's global infrastructure.
- Focus on business growth: Delegate fulfillment to Amazon and free up time and resources to focus on scaling your business.

== Installation ==
1. Install and activate the plugin in your WooCommerce account.
2. Allow the plugin to access your WooCommerce store by clicking \"Accept\".
3. Link your Amazon seller profile (with FBA and MCF enabled) by selecting \“Connect Marketplace Account\”.
4. Follow the 2-step setup guide to link your products and configure order settings.


== Frequently Asked Questions ==
Do I need a subscription to use M2E Multi-Channel Fulfillment by Amazon?
- A 30-day free trial is available. After that, you’ll need to subscribe to one of the available pricing plans.

How do I sign up for Amazon Multi-Channel Fulfillment (MCF)?
- Existing Amazon sellers with a Seller Central account can start using MCF immediately by enabling the option in their account.

New users or sellers looking to use MCF for non-Amazon sales should sign up through Amazon’s Supply Chain Portal.

How do I use Multi-Channel Fulfillment (MCF) on Amazon?
- Once you're signed up for MCF, ship some or all of your products to Amazon’s fulfillment centers. If you’re already using FBA, MCF automatically applies to your inventory.

Next, define how you want to handle order fulfillment. Choose from individual or bulk order creation, or use API integration for automated fulfillment.


== Screenshots ==
1. Dashboard
2. Listings
3. Orders
