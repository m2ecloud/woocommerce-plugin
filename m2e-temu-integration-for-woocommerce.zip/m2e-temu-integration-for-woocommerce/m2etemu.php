<?php
/**
 * Plugin Name:       M2E Temu Connect
 * Plugin URI:        https://temu.m2ecloud.com/
 * Description:       One-click integration between WooCommerce and Temu. Easy inventory and order management.
 * Version:           2.3.9
 * Requires at least: 6.1
 * Requires PHP:      7.2
 * Author:            M2E Cloud
 * Author URI:        https://m2ecloud.com/about
 * License:           GPLv2
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.html
 *
 * Woo:                  
 * WC requires at least: 8.0
 * WC tested up to:      10.5.2
 */

defined( 'ABSPATH' ) || exit;

define( 'M2ETEMU_NAME', 'm2etemu' );
define( 'M2ETEMU_VERSION', '2.3.9' );

if ( ! defined( 'M2ETEMU_PLUGIN_FILE' ) ) {
	define( 'M2ETEMU_PLUGIN_FILE', __FILE__ );
}

require plugin_dir_path( __FILE__ ) . 'includes/class-m2etemu-bootstrap.php';
M2ETEMU_Bootstrap::load_classes();
M2ETEMU_Bootstrap::register_activate();
M2ETEMU_Bootstrap::register_deactivate();

( new M2ETEMU_Bootstrap() )->run();
