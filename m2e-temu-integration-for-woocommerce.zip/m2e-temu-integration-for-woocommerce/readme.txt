=== M2E Temu Connect ===
Tags: temu
Requires at least: 6.1
Tested up to: 6.8.3
Requires PHP: 7.2
Stable tag: 2.3.9
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

M2E Temu Connect helps connect your WooCommerce store with Temu, allowing you to operate your sales data from all platforms in your WooCommerce.

== Description ==

M2E Temu Connect makes it easy to scale your WooCommerce sales across 30 Temu marketplaces. The plugin provides automatic inventory and order synchronization, keeping your product information and order details up-to-date both on WooCommerce and Temu. Whether you’re managing existing Temu listings or looking to list your WooCommerce products on Temu, it's just a few clicks away.

Here’s how else M2E Temu Connect can benefit your business:

- List your entire WooCommerce inventory on Temu with flexible settings
- Manage and fulfill your Temu orders from a user-friendly interface
- Provide Parts Compatibility information for your vehicle parts’ listings on Temu
- Expand your business globally to access new shoppers and boost your sales
- Get prompt help from five-star personalized support

== Installation ==

1. Install and activate the M2E Temu Connect plugin in your WooCommerce admin.
2. After activating the plugin, you'll be prompted to grant access to your WooCommerce account. Click the “Accept” button in the pop-up window to proceed.
3.  Set up your M2E Temu Connect plugin. Connect your Temu account and specify product & order settings. Then, you can enable synchronization for imported Temu items linked with products from your WooCommerce catalog.

== Frequently Asked Questions ==

- How much does M2E Temu Connect cost?
As a new user, you’re eligible for a 30-day free trial that allows you to explore the plugin without any commitment. Once the trial period ends, you will have to subscribe to one of the available pricing plans on m2ecloud.com/pricing. The plans align with your total monthly or yearly sales allowance or GMV. Keep in mind that GMV is calculated only from sales made through the Temu marketplace.

- Can I keep my active Temu listings and upload them to M2E Temu Connect?
The plugin imports your Temu listings, so you may continue selling without any interruptions and maintain your sales ranks. Temu items are automatically linked to the products from your WooCommerce catalog based on the SKU or Product ID.

- Is it safe to synchronize inventory and orders through M2E Temu Connect?
The plugin gives you full control over the synchronization process. Your Temu products and orders will not be updated unless you enable the inventory sync or order management yourself.


