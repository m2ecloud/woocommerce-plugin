<?php

/**
 * The file that defines the core plugin class
 *
 * A class definition that includes attributes and functions used across both the
 * public-facing side of the site and the admin area.
 *
 * @link       http://example.com
 * @since      1.0.0
 * @package    M2ETIKTOK
 * @subpackage M2ETIKTOK/admin
 */

defined( 'ABSPATH' ) || exit;

class M2ETIKTOK_Deactivator {
	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {
		M2ETIKTOK_Helper::clear_auth_data();
	}

}
