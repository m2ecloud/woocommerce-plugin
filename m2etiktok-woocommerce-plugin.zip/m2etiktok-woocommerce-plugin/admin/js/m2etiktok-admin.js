(function ($) {
    'use strict';
})(jQuery);
