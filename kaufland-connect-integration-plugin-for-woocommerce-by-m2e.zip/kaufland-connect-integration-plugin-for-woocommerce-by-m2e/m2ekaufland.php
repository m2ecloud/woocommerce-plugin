<?php
/**
 * Plugin Name:       Kaufland by M2E Cloud
 * Plugin URI:        https://kaufland.m2ecloud.com/
 * Description:       One-click integration between WooCommerce and Kaufland. Easy inventory and order management.
 * Version:           2.3.9
 * Requires at least: 6.1
 * Requires PHP:      7.2
 * Author:            M2E Cloud
 * Author URI:        https://m2ecloud.com/about
 * License:           GPLv2
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.html
 *
 * Woo:                  
 * WC requires at least: 8.0
 * WC tested up to:      10.5.2
 */

defined( 'ABSPATH' ) || exit;

define( 'M2EKAUFLAND_NAME', 'm2ekaufland' );
define( 'M2EKAUFLAND_VERSION', '2.3.9' );

if ( ! defined( 'M2EKAUFLAND_PLUGIN_FILE' ) ) {
	define( 'M2EKAUFLAND_PLUGIN_FILE', __FILE__ );
}

require plugin_dir_path( __FILE__ ) . 'includes/class-m2ekaufland-bootstrap.php';
M2EKAUFLAND_Bootstrap::load_classes();
M2EKAUFLAND_Bootstrap::register_activate();
M2EKAUFLAND_Bootstrap::register_deactivate();

( new M2EKAUFLAND_Bootstrap() )->run();
