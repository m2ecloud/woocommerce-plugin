=== Kaufland by M2E Cloud ===
Tags: kaufland
Requires at least: 6.1
Tested up to: 6.4
Requires PHP: 7.2
Stable tag: 1.0.0
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

M2E Multichannel Connect helps connect your WooCommerce store with Kaufland, allowing you to operate your sales data from all platforms in your WooCommerce admin interface.

== Description ==

M2E Multichannel Connect makes it easy to scale your WooCommerce sales across 30 Kaufland marketplaces. The plugin provides automatic inventory and order synchronization, keeping your product information and order details up-to-date both on WooCommerce and Kaufland. Whether you’re managing existing Kaufland listings or looking to list your WooCommerce products on Kaufland, it's just a few clicks away.

Here’s how else M2E Multichannel Connect can benefit your business:

- List your entire WooCommerce inventory on Kaufland with flexible settings
- Manage and fulfill your Kaufland orders from a user-friendly interface
- Provide Parts Compatibility information for your vehicle parts’ listings on Kaufland
- Expand your business globally to access new shoppers and boost your sales
- Get prompt help from five-star personalized support

== Installation ==

1. Install and activate the M2E Multichannel Connect plugin in your WooCommerce admin.
2. After activating the plugin, you'll be prompted to grant access to your WooCommerce account. Click the “Accept” button in the pop-up window to proceed.
3.  Set up your M2E Multichannel Connect plugin. Connect your Kaufland account and specify product & order settings. Then, you can enable synchronization for imported Kaufland items linked with products from your WooCommerce catalog.

== Frequently Asked Questions ==

- How much does M2E Multichannel Connect cost?
As a new user, you’re eligible for a 30-day free trial that allows you to explore the plugin without any commitment. Once the trial period ends, you will have to subscribe to one of the available pricing plans on m2ecloud.com/pricing. The plans align with your total monthly or yearly sales allowance or GMV. Keep in mind that GMV is calculated only from sales made through the Kaufland marketplace.

- Can I keep my active Kaufland listings and upload them to M2E Multichannel Connect?
The plugin imports your Kaufland listings, so you may continue selling without any interruptions and maintain your sales ranks. Kaufland items are automatically linked to the products from your WooCommerce catalog based on the SKU or Product ID.

- Is it safe to synchronize inventory and orders through M2E Multichannel Connect?
The plugin gives you full control over the synchronization process. Your Kaufland products and orders will not be updated unless you enable the inventory sync or order management yourself.


