<?php

/**
 * The file that defines the core plugin class
 *
 * A class definition that includes attributes and functions used across both the
 * public-facing side of the site and the admin area.
 *
 * @link       http://example.com
 * @since      1.0.0
 * @package    M2EKAUFLAND
 * @subpackage M2EKAUFLAND/admin
 */

defined( 'ABSPATH' ) || exit;

class M2EKAUFLAND_Admin {

	/**
	 * The Facade object which interact with WordPress.
	 *
	 * @var M2EKAUFLAND_Facade
	 */
	private $facade;

	public function __construct( M2EKAUFLAND_Facade $facade ) {
		$this->facade = $facade;
	}

	// used only for a debugging on local installation
	// nosemgrep: audit.php.lang.misc.curl-ssl-unverified
//	public function disable_ssl_check( $curl ) {
//		curl_setopt( $curl, CURLOPT_SSL_VERIFYHOST, 0 );
//		curl_setopt( $curl, CURLOPT_SSL_VERIFYPEER, 0 );
//	}

	public function check_auth() {
		if ( ! M2EKAUFLAND_Helper::has_auth_data() ) {
			wp_safe_redirect( site_url() . '/wc-auth/v1/authorize?' . M2EKAUFLAND_Helper::build_authorize_params() );
		}
	}

	public function add_plugin_links( $links ) {
		$action_links = [
			'listings' => '<a href="' . admin_url( 'admin.php?page=m2ekaufland' ) . '" title="' . esc_html__( 'Manage Kaufland Listings', 'm2ekaufland' ) . '">' . esc_html__( 'Manage Kaufland Listings', 'm2ekaufland' ) . '</a>',
			'settings' => '<a href="' . admin_url( 'admin.php?page=m2ekaufland-settings' ) . '" title="' . esc_html__( 'Settings', 'm2ekaufland' ) . '">' . esc_html__( 'Settings', 'm2ekaufland' ) . '</a>',
		];

		return array_merge( $action_links, $links );
	}

	public function init_menu() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}

		$this->facade->add_menu_item(
			__( 'Kaufland by M2E Cloud', 'm2ekaufland' ),
			__( 'Kaufland by M2E', 'm2ekaufland' ),
			'edit_posts',
			M2EKAUFLAND_NAME,
			function () {
				$this->render_page( '/app/dashboard' );
			},
			'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgdmlld0JveD0iMCAwIDIwMCAyMDAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxwYXRoIGQ9Ik0zMy4xNTE0IDEwNS4yMjRIOTQuNzAwMlYxNjYuNzYzSDMzLjE1MTRWMTA1LjIyNFpNMTA1LjIwOSAxNjYuNzMzSDE2Ni43ODhMMTA1LjIwOSAxMDUuMTYzVjE2Ni43MzNaTTEwNS4yNyAzMy4yMzE1Vjk0LjgwMTJMMTY2Ljg0OSAzMy4yMzE1SDEwNS4yN1pNMzMuMjM2MyAzMy4yMzE1SDk0Ljc4NTFWOTQuNzcwOUgzMy4yMzYzVjMzLjIzMTVaIiBmaWxsPSIjRTEwOTE1Ii8+CjxwYXRoIGQ9Ik0wIDE5OS45OTRIMjAwVjBIMFYyMDBWMTk5Ljk5NFpNMTkwLjg2NCAxOTEuMzI4TDguNzY0MTggMTkxLjMyMlY4Ljc2Mjg1SDE5MC44NjRWMTkxLjMyOFoiIGZpbGw9IiNFMTA5MTUiLz4KPC9zdmc+Cg==',
			'56.504',
			[ $this, 'check_auth' ]
		);
	}

	private function render_page( $path ) {
		$params = [
			'woocommerce_embedded' => '1',
			'session_token' => M2EKAUFLAND_Helper::build_jwt_token(),
		];
		$url = M2EKAUFLAND_Helper::get_server_endpoint() . $path . '?' . http_build_query( $params );
		?>
		<iframe class="m2ekaufland-frame" src="<?php echo esc_url( $url ); ?>" frameborder="0"></iframe>
		<?php
	}
}
