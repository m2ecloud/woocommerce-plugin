<?php
/**
 * Plugin Name:       Kaufland by M2E Cloud
 * Plugin URI:        https://kaufland.m2ecloud.com/
 * Description:       One-click integration between WooCommerce and Kaufland. Easy inventory and order management.
 * Version:           1.0.0
 * Requires at least: 6.1
 * Requires PHP:      7.2
 * Author:            M2E Cloud
 * Author URI:        https://m2ecloud.com/about
 * License:           GPLv2
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.html
 *
 * Woo:                  18734004130839:b744450f2be1d9e887835ad0fb374e78
 * WC requires at least: 8.0.0
 * WC tested up to:      8.0.2
 */

defined( 'ABSPATH' ) || exit;

define( 'M2EKAUFLAND_NAME', 'm2ekaufland' );
define( 'M2EKAUFLAND_VERSION', '1.0.0' );

if ( ! defined( 'M2EKAUFLAND_PLUGIN_FILE' ) ) {
	define( 'M2EKAUFLAND_PLUGIN_FILE', __FILE__ );
}

require plugin_dir_path( __FILE__ ) . 'includes/class-m2ekaufland-bootstrap.php';
M2EKAUFLAND_Bootstrap::load_classes();
M2EKAUFLAND_Bootstrap::register_activate();
M2EKAUFLAND_Bootstrap::register_deactivate();

( new M2EKAUFLAND_Bootstrap() )->run();
