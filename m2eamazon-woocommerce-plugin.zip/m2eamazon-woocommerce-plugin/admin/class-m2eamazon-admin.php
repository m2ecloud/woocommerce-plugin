<?php

/**
 * The file that defines the core plugin class
 *
 * A class definition that includes attributes and functions used across both the
 * public-facing side of the site and the admin area.
 *
 * @link       http://example.com
 * @since      1.0.0
 * @package    M2EAMAZON
 * @subpackage M2EAMAZON/admin
 */

defined( 'ABSPATH' ) || exit;

class M2EAMAZON_Admin {

	/**
	 * The Facade object which interact with WordPress.
	 *
	 * @var M2EAMAZON_Facade
	 */
	private $facade;

	public function __construct( M2EAMAZON_Facade $facade ) {
		$this->facade = $facade;
	}

	public function disable_ssl_check( $curl ) {
		curl_setopt( $curl, CURLOPT_SSL_VERIFYHOST, 0 );
		curl_setopt( $curl, CURLOPT_SSL_VERIFYPEER, 0 );
	}

	public function check_auth() {
		if ( ! M2EAMAZON_Helper::has_auth_data() ) {
			wp_redirect( site_url() . '/wc-auth/v1/authorize?' . M2EAMAZON_Helper::build_authorize_params() );
		}
	}

	public function add_plugin_links( $links ) {
		$action_links = [
			'listings' => '<a href="' . admin_url( 'admin.php?page=m2eamazon' ) . '" title="' . esc_html__( 'Manage Amazon Listings', 'm2eamazon' ) . '">' . esc_html__( 'Manage Amazon Listings', 'm2eamazon' ) . '</a>',
			'settings' => '<a href="' . admin_url( 'admin.php?page=m2eamazon-settings' ) . '" title="' . esc_html__( 'Settings', 'm2eamazon' ) . '">' . esc_html__( 'Settings', 'm2eamazon' ) . '</a>',
		];

		return array_merge( $action_links, $links );
	}

	public function init_menu() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}

		$this->facade->add_menu_item(
			__( 'Amazon by M2E Cloud', 'm2eamazon' ),
			__( 'Amazon by M2E', 'm2eamazon' ),
			'edit_posts',
			M2EAMAZON_NAME,
			function () {
				$this->render_page( '/app/dashboard' );
			},
			'data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+CjxzdmcKICAgd2lkdGg9IjU4IgogICBoZWlnaHQ9IjU4IgogICB2aWV3Qm94PSIwIDAgNTggNTgiCiAgIGZpbGw9Im5vbmUiCiAgIHZlcnNpb249IjEuMSIKICAgaWQ9InN2ZzIiCiAgIHNvZGlwb2RpOmRvY25hbWU9ImFtYXpvbi5zdmciCiAgIGlua3NjYXBlOnZlcnNpb249IjEuMyAoMGUxNTBlZCwgMjAyMy0wNy0yMSkiCiAgIHhtbG5zOmlua3NjYXBlPSJodHRwOi8vd3d3Lmlua3NjYXBlLm9yZy9uYW1lc3BhY2VzL2lua3NjYXBlIgogICB4bWxuczpzb2RpcG9kaT0iaHR0cDovL3NvZGlwb2RpLnNvdXJjZWZvcmdlLm5ldC9EVEQvc29kaXBvZGktMC5kdGQiCiAgIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIKICAgeG1sbnM6c3ZnPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CiAgPGRlZnMKICAgICBpZD0iZGVmczIiIC8+CiAgPHNvZGlwb2RpOm5hbWVkdmlldwogICAgIGlkPSJuYW1lZHZpZXcyIgogICAgIHBhZ2Vjb2xvcj0iI2ZmZmZmZiIKICAgICBib3JkZXJjb2xvcj0iIzAwMDAwMCIKICAgICBib3JkZXJvcGFjaXR5PSIwLjI1IgogICAgIGlua3NjYXBlOnNob3dwYWdlc2hhZG93PSIyIgogICAgIGlua3NjYXBlOnBhZ2VvcGFjaXR5PSIwLjAiCiAgICAgaW5rc2NhcGU6cGFnZWNoZWNrZXJib2FyZD0iMCIKICAgICBpbmtzY2FwZTpkZXNrY29sb3I9IiNkMWQxZDEiCiAgICAgc2hvd2dyaWQ9ImZhbHNlIgogICAgIGlua3NjYXBlOnpvb209IjExLjIwNjg5NyIKICAgICBpbmtzY2FwZTpjeD0iMjguOTU1Mzg1IgogICAgIGlua3NjYXBlOmN5PSIyOSIKICAgICBpbmtzY2FwZTp3aW5kb3ctd2lkdGg9IjE1MTIiCiAgICAgaW5rc2NhcGU6d2luZG93LWhlaWdodD0iODYzIgogICAgIGlua3NjYXBlOndpbmRvdy14PSIwIgogICAgIGlua3NjYXBlOndpbmRvdy15PSIzOCIKICAgICBpbmtzY2FwZTp3aW5kb3ctbWF4aW1pemVkPSIxIgogICAgIGlua3NjYXBlOmN1cnJlbnQtbGF5ZXI9InN2ZzIiIC8+CiAgPHBhdGgKICAgICBkPSJtIDQ4LjA0NTQxOSw0NS4wMDA4OTMgYyAtNS4xMjc0MzIsMy40MjUwOTggLTEyLjY3NTg4Niw1LjI2NjI0NiAtMTkuMTMyNDg2LDUuMjY2MjQ2IC05LjA0Mzk0NSwwIC0xNy4yMDk2MjQsLTMuMDE4NDU1IC0yMy4zODE0NDU3LC04LjA0OTI3NyAtMC40NzQ2MjgzLC0wLjM4NTQyNSAtMC4wNDc0NTgsLTAuOTIwNDggMC41OTM0OTI0LC0wLjYyMDg0OSA2LjU5ODk5MDMsMy40ODk0ODkgMTQuODM1ODU4Myw1LjU4NzQ2NCAyMy4zMzM5ODIzLDUuNTg3NDY0IDUuNzIwNzE5LDAgMTIuMDM0OTMzLC0xLjA3MDQ4MyAxNy44MjY4NDUsLTMuMjc1NDY4IDAuODc4MjY5LC0wLjM0MjQzNCAxLjU2NjY4OCwwLjUxMzgzOSAwLjc1OTYxMiwxLjA5MTg4NCB6IG0gMi4xNTk5NzUsLTIuMjI2Mzg4IGMgLTAuNjY0NDgxLC0wLjc3MDY2NSAtNC4zOTEzNDcsLTAuMzY0MDI0IC02LjEwMDQyNCwtMC4xNzEyMTYgLTAuNDUxMTA1LDAuMDQyNzkgLTAuNTIyMjk4LC0wLjM0MjYyMyAtMC4wNzEyLC0wLjY0MjI1MiAyLjk0MzMxNywtMS44ODM5NTQgNy44MDk0OTksLTEuMzI3MzExIDguMzc5MjU5LC0wLjcwNjQ2IDAuNTY5NzYxLDAuNjQyMjUzIC0wLjE2NjEyLDUuMDMwODIxIC0yLjk0MzUyMyw3LjEwNzIwOCAtMC40MjcxNjYsMC4zNDI2MjEgLTAuODMwODA3LDAuMTUwMDA2IC0wLjYxNzAxOCwtMC4yMzU0MjUgMC42MTcwMTgsLTEuNDM0MzIgMi4wMTc1ODYsLTQuNTgxMTg5IDEuMzUyOSwtNS4zNTE4NTUgeiIKICAgICBmaWxsPSIjMjIyYjQ1IgogICAgIGlkPSJwYXRoMSIKICAgICBzdHlsZT0iZmlsbDojZjlmOWY5O3N0cm9rZS13aWR0aDoxLjk1OTcxIiAvPgogIDxwYXRoCiAgICAgZD0ibSAzOS45ODQzNjksMzkuNzU2NDIzIGMgLTAuNDI3MTY2LDAuMzQyNjIxIC0xLjAyMDY1OCwwLjM2NDAyMiAtMS40OTUyODcsMC4xMjg0MTYgLTIuMTEyNzE4LC0xLjU4NDEzNSAtMi40OTI0MiwtMi4zMTE5OTYgLTMuNjU1NjczLC0zLjgzMTkyNSAtMy40ODkzNDUsMy4yMTEyNiAtNS45NTgwMzQsNC4xNzQ1NDcgLTEwLjQ5MTk3Niw0LjE3NDU0NyAtNS4zNDA4MTEsMCAtOS41MTg3OCwtMi45NzU2NTEgLTkuNTE4NzgsLTguOTI2OTUzIDAsLTQuNjY2OTg0IDIuNzc3NDAzLC03Ljc5MjQ1IDYuNzg5MDQ3LC05LjM3NjU4NSAzLjQ2NTYxNSwtMS4zNzAxMTQgOC4yODQzMzIsLTEuNjI2OTM5IDExLjk2MzczNywtMS45OTA5NjMgdiAtMC43MDY0NTkgYyAwLC0xLjQxMjkxOSAwLjExODY1OCwtMy4wMTg0NTYgLTAuNzgzMzQ0LC00LjE5NTk1IC0wLjc1OTYxMywtMS4wNDg4OTQgLTIuMjU1MTA0LC0xLjQ5ODUyNiAtMy41NjA3NDcsLTEuNDk4NTI2IC0yLjQyMTIyNSwwIC00LjU4MTQwMywxLjEzNDY4OCAtNS4xMDM0OTYsMy40NDY2ODUgLTAuMTE4NjU4LDAuNTEzODM5IC0wLjU5MzQ5MiwxLjAyNzY3OCAtMS4xMTU3ODksMS4wNDkwODEgbCAtNi4xNzE2MTcsLTAuNTk5NDQ4IGMgLTAuNTIyMjk4LC0wLjEwNzAwNyAtMS4wOTIwNTksLTAuNDcxMDM0IC0wLjk0OTQ2NSwtMS4xOTg4OTYgMS40MjQwOTIsLTYuNzQzMzcgOC4xODk0MDksLTguNzc3MTM3MiAxNC4yNDIzNjgsLTguNzc3MTM3MiAzLjA4NTkxMSwwIDcuMTIxMjg3LDAuNzQ5MjYzNCA5LjU2NjI0NSwyLjg0NzIzNzIgMy4wODU5MTEsMi42MTE4MTQgMi44MjQ4NjQsNi4xMDExMTkgMi44MjQ4NjQsOS44OTA0MjQgdiA4LjkyNjk1NCBjIDAsMi42NzU4MzIgMS4xODY3NzksMy44NzQ3MjkgMi4zNzM3NjMsNS4zMDkwNDkgMC40MDM0MzQsMC41MzUyNDIgMC40OTgzNiwxLjE1NjA5MSAwLDEuNTE5OTI5IGwgLTQuODkwMTIsMy44MTA1MjIgeiBNIDMzLjU3NTQzNywyNS43NzcyNDYgdiAtMS4xOTg3MDggYyAtNC42MDUxMzgsMCAtOS40NzEzMTgsMC44MzQ4NzIgLTkuNDcxMzE4LDUuNzE1NjkxIDAsMi40ODM0IDEuNDQ4MDMxLDQuMTc0NTQ2IDMuODY5MjU0LDQuMTc0NTQ2IDEuODA0MDAyLDAgMy4zOTQ0MjEsLTEuMDA2MDkgNC40MTUwNzksLTIuNjExODE0IDEuMjM0NDQ4LC0xLjk5MDc3OCAxLjE4Njk4NSwtMy44NTMzMjcgMS4xODY5ODUsLTYuMDc5NzE1IHoiCiAgICAgZmlsbD0iIzIyMmI0NSIKICAgICBpZD0icGF0aDIiCiAgICAgc3R5bGU9ImZpbGw6I2Y5ZjlmOTtzdHJva2Utd2lkdGg6MS45NTk3MSIgLz4KPC9zdmc+Cg==',
			'56.502',
			[ $this, 'check_auth' ]
		);
	}

	private function render_page( $path ) {
		$params = [
			'woocommerce_embedded' => '1',
			'session_token' => M2EAMAZON_Helper::build_jwt_token(),
		];
		$url = M2EAMAZON_Helper::get_server_endpoint() . $path . '?' . http_build_query( $params );
		?>
		<iframe class="m2eamazon-frame" src="<?php echo esc_url( $url ); ?>" frameborder="0"></iframe>
		<?php
	}
}
