<?php

defined( 'ABSPATH' ) || exit;

?>

<div class="wrap">
	<h1>WordPress multi-site is currently not supported by M2E Cloud: Sales Channels</h1>
	<p>Please <a target="_blank" href="#">click here for more information</a>.</p>
</div>

<?php
include(ABSPATH . 'wp-admin/admin-footer.php' );
