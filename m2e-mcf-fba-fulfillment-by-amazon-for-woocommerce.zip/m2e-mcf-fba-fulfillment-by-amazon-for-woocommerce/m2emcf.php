<?php
/**
 * Plugin Name:       M2E Multi-Channel Fulfillment by Amazon
 * Plugin URI:        https://mcf.m2ecloud.com/
 * Description:       One-click integration between WooCommerce and Amazon MCF. Easy inventory and order management.
 * Version:           2.3.9
 * Requires at least: 6.1
 * Requires PHP:      7.2
 * Author:            M2E Cloud
 * Author URI:        https://m2ecloud.com/about
 * License:           GPLv2
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.html
 *
 * Woo:                  
 * WC requires at least: 8.0
 * WC tested up to:      10.5.2
 */

defined( 'ABSPATH' ) || exit;

define( 'M2EMCF_NAME', 'm2emcf' );
define( 'M2EMCF_VERSION', '2.3.9' );

if ( ! defined( 'M2EMCF_PLUGIN_FILE' ) ) {
	define( 'M2EMCF_PLUGIN_FILE', __FILE__ );
}

require plugin_dir_path( __FILE__ ) . 'includes/class-m2emcf-bootstrap.php';
M2EMCF_Bootstrap::load_classes();
M2EMCF_Bootstrap::register_activate();
M2EMCF_Bootstrap::register_deactivate();

( new M2EMCF_Bootstrap() )->run();
