<?php

/**
 * The file that defines the core plugin class
 *
 * A class definition that includes attributes and functions used across both the
 * public-facing side of the site and the admin area.
 *
 * @link       http://example.com
 * @since      1.0.0
 * @package    M2EMCF
 * @subpackage M2EMCF/admin
 */

defined( 'ABSPATH' ) || exit;

class M2EMCF_Admin {

	/**
	 * The Facade object which interact with WordPress.
	 *
	 * @var M2EMCF_Facade
	 */
	private $facade;

	public function __construct( M2EMCF_Facade $facade ) {
		$this->facade = $facade;
	}

	// used only for a debugging on local installation
	// nosemgrep: audit.php.lang.misc.curl-ssl-unverified
//	public function disable_ssl_check( $curl ) {
//		curl_setopt( $curl, CURLOPT_SSL_VERIFYHOST, 0 );
//		curl_setopt( $curl, CURLOPT_SSL_VERIFYPEER, 0 );
//	}

	public function check_auth() {
		if ( ! M2EMCF_Helper::has_auth_data() ) {
			wp_safe_redirect( site_url() . '/wc-auth/v1/authorize?' . M2EMCF_Helper::build_authorize_params() );
		}
	}

	public function add_plugin_links( $links ) {
		$action_links = [
			'listings' => '<a href="' . admin_url( 'admin.php?page=m2emcf' ) . '" title="' . esc_html__( 'Manage Amazon MCF Listings', 'm2e-fulfillment-by-amazon-fba-mcf-woocommerce' ) . '">' . esc_html__( 'Manage Amazon MCF Listings', 'm2e-fulfillment-by-amazon-fba-mcf-woocommerce' ) . '</a>'
		];

		return array_merge( $action_links, $links );
	}

	public function init_menu() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}

		$this->facade->add_menu_item(
			__( 'M2E Multi-Channel Fulfillment by Amazon', 'm2e-fulfillment-by-amazon-fba-mcf-woocommerce' ),
			__( 'MCF by M2E', 'm2e-fulfillment-by-amazon-fba-mcf-woocommerce' ),
			'edit_posts',
			M2EMCF_NAME,
			function () {
				$this->render_page( '/app/dashboard' );
			},
			'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNTgiIGhlaWdodD0iNTkiIHZpZXdCb3g9IjAgMCA1OCA1OSIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZD0iTTQ3Ljg1NyA0Mi4xMzI5QzI2LjU4OTggNTAuNzU0OCAxMy4zOTExIDQzLjU0MTEgNC45NDIxOSAzOS4xNTk2QzQuNDE5MzcgMzguODgzNSAzLjUzMDc3IDM5LjIyNDIgNC4zMDE3NSAzOS45Nzg2QzcuMTE2NSA0Mi44ODU5IDE2LjM0MSA0OS44OTM0IDI4LjM4MTcgNDkuODkzNEM0MC40MzA3IDQ5Ljg5MzQgNDcuNTk4NyA0NC4yOTI5IDQ4LjQ5NTQgNDMuMzE1OUM0OS4zODYgNDIuMzQ3MiA0OC43NTY5IDQxLjgxMjkgNDcuODU2OCA0Mi4xMzI5SDQ3Ljg1N1pNNTMuODI5OSAzOS4zMjNDNTMuMjU4OCAzOC42ODk1IDUwLjM1NzEgMzguNTcxNCA0OC41MzEgMzguNzYyNUM0Ni43MDIxIDM4Ljk0ODEgNDMuOTU2OCAzOS45MDAyIDQ0LjE5NTUgNDAuNDcyQzQ0LjMxOCA0MC42ODYxIDQ0LjU2OCA0MC41OTAxIDQ1LjgyNDQgNDAuNDkzOEM0Ny4wODQyIDQwLjM4NjcgNTAuNjEzNiA0MC4wMDczIDUxLjM0OSA0MC44MjYyQzUyLjA4NzggNDEuNjUwOSA1MC4yMjMzIDQ1LjU3OTEgNDkuODgyOCA0Ni4yMTI2QzQ5LjU1MzggNDYuODQ2MSA1MC4wMDg1IDQ3LjAwOTUgNTAuNjI2NSA0Ni41ODc1QzUxLjIzNiA0Ni4xNjU3IDUyLjMzOTQgNDUuMDczNCA1My4wNzk5IDQzLjUyNzdDNTMuODE1MyA0MS45NzM1IDU0LjI2NCAzOS44MDU0IDUzLjgyOTkgMzkuMzIzWiIgZmlsbD0iI0IzQjNCMyIvPgo8cGF0aCBkPSJNNDcuODU3IDQyLjEzMjlDMjYuNTg5OCA1MC43NTQ4IDEzLjM5MTEgNDMuNTQxMSA0Ljk0MjE5IDM5LjE1OTZDNC40MTkzNyAzOC44ODM1IDMuNTMwNzcgMzkuMjI0MiA0LjMwMTc1IDM5Ljk3ODZDNy4xMTY1IDQyLjg4NTkgMTYuMzQxIDQ5Ljg5MzQgMjguMzgxNyA0OS44OTM0QzQwLjQzMDcgNDkuODkzNCA0Ny41OTg3IDQ0LjI5MjkgNDguNDk1NCA0My4zMTU5QzQ5LjM4NiA0Mi4zNDcyIDQ4Ljc1NjkgNDEuODEyOSA0Ny44NTY4IDQyLjEzMjlINDcuODU3Wk01My44Mjk5IDM5LjMyM0M1My4yNTg4IDM4LjY4OTUgNTAuMzU3MSAzOC41NzE0IDQ4LjUzMSAzOC43NjI1QzQ2LjcwMjEgMzguOTQ4MSA0My45NTY4IDM5LjkwMDIgNDQuMTk1NSA0MC40NzJDNDQuMzE4IDQwLjY4NjEgNDQuNTY4IDQwLjU5MDEgNDUuODI0NCA0MC40OTM4QzQ3LjA4NDIgNDAuMzg2NyA1MC42MTM2IDQwLjAwNzMgNTEuMzQ5IDQwLjgyNjJDNTIuMDg3OCA0MS42NTA5IDUwLjIyMzMgNDUuNTc5MSA0OS44ODI4IDQ2LjIxMjZDNDkuNTUzOCA0Ni44NDYxIDUwLjAwODUgNDcuMDA5NSA1MC42MjY1IDQ2LjU4NzVDNTEuMjM2IDQ2LjE2NTcgNTIuMzM5NCA0NS4wNzM0IDUzLjA3OTkgNDMuNTI3N0M1My44MTUzIDQxLjk3MzUgNTQuMjY0IDM5LjgwNTQgNTMuODI5OSAzOS4zMjNaIiBmaWxsPSIjQjNCM0IzIi8+CjxwYXRoIGQ9Ik00NC4wMTcgMTQuNTE3MVYzMC4wODAxSDQwLjgxMDNWMTQuNTE3MUg0NC4wMTdaTTUwLjIxNjUgMjEuMTY1NlYyMy42NjY4SDQzLjE0MDVWMjEuMTY1Nkg1MC4yMTY1Wk01MC45NjQ3IDE0LjUxNzFWMTcuMDI5SDQzLjE0MDVWMTQuNTE3MUg1MC45NjQ3WiIgZmlsbD0iI0IzQjNCMyIvPgo8cGF0aCBkPSJNMzUuNTA4NiAyNC45MTcySDM4LjcwNDVDMzguNjQwNCAyNS45NjQ3IDM4LjM1MTggMjYuODk0NiAzNy44Mzg3IDI3LjcwN0MzNy4zMzI4IDI4LjUxOTQgMzYuNjIzOCAyOS4xNTM2IDM1LjcxMTYgMjkuNjA5NkMzNC44MDY3IDMwLjA2NTcgMzMuNzE2NCAzMC4yOTM3IDMyLjQ0MDggMzAuMjkzN0MzMS40NDMyIDMwLjI5MzcgMzAuNTQ4OSAzMC4xMjI3IDI5Ljc1NzkgMjkuNzgwNkMyOC45NjcgMjkuNDMxNSAyOC4yOSAyOC45MzI3IDI3LjcyNzEgMjguMjg0MkMyNy4xNzEyIDI3LjYzNTcgMjYuNzQ3MyAyNi44NTE5IDI2LjQ1NTEgMjUuOTMyNkMyNi4xNjI5IDI1LjAxMzQgMjYuMDE2OCAyMy45ODM3IDI2LjAxNjggMjIuODQzNlYyMS43NjRDMjYuMDE2OCAyMC42MjM4IDI2LjE2NjUgMTkuNTk0MiAyNi40NjU4IDE4LjY3NDlDMjYuNzcyMiAxNy43NDg1IDI3LjIwNjkgMTYuOTYxMSAyNy43Njk4IDE2LjMxMjdDMjguMzM5OSAxNS42NjQyIDI5LjAyMDQgMTUuMTY1NCAyOS44MTE0IDE0LjgxNjJDMzAuNjAyNCAxNC40NjcxIDMxLjQ4NiAxNC4yOTI1IDMyLjQ2MjIgMTQuMjkyNUMzMy43NTkxIDE0LjI5MjUgMzQuODUzIDE0LjUyNzYgMzUuNzQzNyAxNC45OTc5QzM2LjY0MTYgMTUuNDY4MyAzNy4zMzYzIDE2LjExNjcgMzcuODI4IDE2Ljk0MzNDMzguMzI2OCAxNy43Njk5IDM4LjYyNjEgMTguNzEwNSAzOC43MjU5IDE5Ljc2NTJIMzUuNTE5MkMzNS40ODM2IDE5LjEzODEgMzUuMzU4OSAxOC42MDcyIDM1LjE0NTEgMTguMTcyNUMzNC45MzE0IDE3LjczMDcgMzQuNjA3MSAxNy4zOTk0IDM0LjE3MjQgMTcuMTc4NUMzMy43NDQ5IDE2Ljk1MDQgMzMuMTc0OCAxNi44MzY0IDMyLjQ2MjIgMTYuODM2NEMzMS45Mjc4IDE2LjgzNjQgMzEuNDYxIDE2LjkzNjIgMzEuMDYyIDE3LjEzNTdDMzAuNjYyOSAxNy4zMzUyIDMwLjMyOCAxNy42MzgxIDMwLjA1NzIgMTguMDQ0M0MyOS43ODY0IDE4LjQ1MDQgMjkuNTgzNCAxOC45NjM1IDI5LjQ0OCAxOS41ODM1QzI5LjMxOTcgMjAuMTk2MyAyOS4yNTU2IDIwLjkxNiAyOS4yNTU2IDIxLjc0MjZWMjIuODQzNkMyOS4yNTU2IDIzLjY0ODggMjkuMzE2MSAyNC4zNTc4IDI5LjQzNzMgMjQuOTcwN0MyOS41NTg0IDI1LjU3NjQgMjkuNzQzNyAyNi4wODk0IDI5Ljk5MzEgMjYuNTA5OEMzMC4yNDk2IDI2LjkyMzIgMzAuNTc3NCAyNy4yMzY3IDMwLjk3NjUgMjcuNDUwNUMzMS4zODI3IDI3LjY1NzEgMzEuODcwOCAyNy43NjA0IDMyLjQ0MDggMjcuNzYwNEMzMy4xMTA3IDI3Ljc2MDQgMzMuNjYyOSAyNy42NTM2IDM0LjA5NzYgMjcuNDM5OEMzNC41MzIzIDI3LjIyNiAzNC44NjM3IDI2LjkwODkgMzUuMDkxNyAyNi40ODg1QzM1LjMyNjggMjYuMDY4IDM1LjQ2NTggMjUuNTQ0MyAzNS41MDg2IDI0LjkxNzJaIiBmaWxsPSIjQjNCM0IzIi8+CjxwYXRoIGQ9Ik04Ljc3NTc4IDE0LjUxNzFIMTEuNDkwN0wxNS40ODg0IDI1Ljk0MzVMMTkuNDg2IDE0LjUxNzFIMjIuMjAxTDE2LjU3ODYgMzAuMDgwMUgxNC4zOTgxTDguNzc1NzggMTQuNTE3MVpNNy4zMTE0IDE0LjUxNzFIMTAuMDE1N0wxMC41MDc0IDI1LjY1NDlWMzAuMDgwMUg3LjMxMTRWMTQuNTE3MVpNMjAuOTYxMSAxNC41MTcxSDIzLjY3NlYzMC4wODAxSDIwLjQ2OTRWMjUuNjU0OUwyMC45NjExIDE0LjUxNzFaIiBmaWxsPSIjQjNCM0IzIi8+Cjwvc3ZnPgo=',
			'56.504',
			[ $this, 'check_auth' ]
		);
	}

	private function render_page( $path ) {
		$params = [
			'woocommerce_embedded' => '1',
			'session_token' => M2EMCF_Helper::build_jwt_token(),
		];
		$url = M2EMCF_Helper::get_server_endpoint() . $path . '?' . http_build_query( $params );
		?>
		<iframe class="m2emcf-frame" src="<?php echo esc_url( $url ); ?>" frameborder="0"></iframe>
		<?php
	}
}
